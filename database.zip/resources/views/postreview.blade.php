@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        @foreach ($reviewrequest as $reviewrequestval)
        <div class="col-md-8">
            <div class="card">
                <?php $log = DB::table('users')->where('id', $reviewrequestval->request_from)->first(); // or whatever, just get one log ?>
                <div class="card-header">Please Write Review For <?php echo $log->company_name;?></div>

                <div class="card-body">

                        <div class="alert alert-success" role="alert">
                            <form method="POST" id="submitreview" name="submitreview">
                                @csrf
                                {{ method_field('POST') }}
                                <input type="hidden" value="{{ $requestId }}" name="requestId" id="requestId">
                                <input type="hidden" value="{{ $log->google_location }}" name="redirectUrl" id="redirectUrl">

                                <div class="form-group row">
                                    <label for="review" class="col-md-4 col-form-label text-md-right">{{ __('Write Your Review') }}</label>

                                    <div class="col-md-6">
                                        <textarea id="review"  class="form-control @error('review') is-invalid @enderror" name="review" value="{{ old('review') }}" required autocomplete="review" autofocus></textarea>

                                        @error('review')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $review }}</strong>
                                            </span>
                                        @enderror
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="rating" class="col-md-4 col-form-label text-md-right">{{ __('Phone') }}</label>

                                    <div class="col-md-6">
                                        <select id="rating" class="form-control" name="rating" required autocomplete="rating">
                                            <option value="1">1</option>
                                            <option value="2">2</option>
                                            <option value="3">3</option>
                                            <option value="4">4</option>
                                            <option value="5">5</option>
                                        </select>
                                    </div>
                                </div>



                                <div class="form-group row mb-0">
                                    <div class="col-md-8 offset-md-4">
                                        <button type="submit" id="submituserreview" class="btn btn-primary">
                                            {{ __('SUBMIT YOUR REVIEW') }}
                                        </button>
                                    </div>
                                    <div id="response"></div>
                                </div>

                            </form>
                        </div>

                </div>
            </div>
        </div>
        @endforeach
    </div>
</div>
@endsection
