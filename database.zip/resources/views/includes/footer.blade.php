<footer class="x-colophon top">
    <div class="x-container max width">

        <div class="x-column x-md x-1-4">
            <div id="text-2" class="widget widget_text">
                <div class="textwidget">
                    <p><img src="{{ asset('frontassets/image/logo.png') }}" alt="Logo"></p>
                </div>
            </div>
        </div>
        <div class="x-column x-md x-1-4">
            <div id="text-3" class="widget widget_text">
                <h4 class="h-widget">Contact</h4>
                <div class="textwidget">
                    <p>123 Imaginary Drive<br>
                        Danbury, Connecticut<br>
                        <i class="x-icon x-icon-phone" data-x-icon-s="" aria-hidden="true"></i> 555.555.1234<br>
                        <i class="x-icon x-icon-envelope" data-x-icon-s="" aria-hidden="true"></i> hello@example.com
                    </p>
                </div>
            </div>
        </div>
        <div class="x-column x-md x-1-4">
            <div id="text-4" class="widget widget_text">
                <h4 class="h-widget">Quicklinks</h4>
                <div class="textwidget">
                    <p><a href="#">Staff Email</a><br>
                        <a href="#">Student Email</a><br>
                        <a href="#">eLearning Portal</a>
                    </p>
                </div>
            </div>
        </div>
        <div class="x-column x-md x-1-4 last">
            <div id="text-5" class="widget widget_text">
                <h4 class="h-widget">Legal</h4>
                <div class="textwidget">
                    <p><a href="#">Terms &amp; Conditions</a><br>
                        <a href="#">Privacy</a><br>
                        <a href="#">Cookies</a>
                    </p>
                </div>
            </div>
        </div>
    </div>
</footer>
<footer class="x-colophon bottom" role="contentinfo">
    <div class="x-container max width">

        <div class="x-social-global"><a href="" class="facebook" title="Facebook" target="blank" rel=""><i class="x-icon-facebook-square" data-x-icon-b="" aria-hidden="true"></i></a><a href="" class="twitter" title="Twitter" target="blank" rel=""><i class="x-icon-twitter-square" data-x-icon-b="" aria-hidden="true"></i></a><a href="" class="google-plus" title="Google+" target="blank" rel=""><i class="x-icon-google-plus-square" data-x-icon-b="" aria-hidden="true"></i></a><a href="" class="linkedin" title="LinkedIn" target="blank" rel=""><i class="x-icon-linkedin-square" data-x-icon-b="" aria-hidden="true"></i></a><a href="" class="youtube" title="YouTube" target="blank" rel=""><i class="x-icon-youtube-square" data-x-icon-b="" aria-hidden="true"></i></a></div>

        <ul id="menu-primary-menu-2" class="x-nav">
            <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-388 current_page_item menu-item-391"><a title="Home" href="" aria-current="page">Home</a></li>
            <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-390"><a title="About" href="">About</a></li>
            <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-389"><a title="Admissions" href="">Admissions</a></li>
            <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-399"><a href="">News &amp; Events</a></li>
            <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-393"><a title="Contact" href="">Contact</a></li>
        </ul>
        <div class="x-colophon-content">
            <p style="letter-spacing: 2px; text-transform: uppercase;">Powered By <a href="" target="_blank">Themeco</a></p>
        </div>

    </div>
</footer>




<div class="x-searchform-overlay">
    <div class="x-searchform-overlay-inner">
        <div class="x-container max width">
            <form method="get" id="searchform" class="form-search center-text" action="" form_signature="8661829862036458374">
                <label for="s" class="cfc-h-tx tt-upper">Type and Press “enter” to Search</label>
                <input type="text" id="s" class="search-query cfc-h-tx center-text tt-upper" name="s" field_signature="1784043451" form_signature="8661829862036458374">
            </form>
        </div>
    </div>
</div>


</div> <!-- END .x-site -->


<a class="x-scroll-top right fade" title="Back to Top">

    <i class="x-icon-angle-up" data-x-icon-s=""></i>
</a>

<script>
    jQuery(document).ready(function($) {

        var $window = $(window);
        var body = $('body');
        var bodyOffsetBottom = $window.scrollBottom(); // 1
        var bodyHeightAdjustment = body.height() - bodyOffsetBottom; // 2
        var bodyHeightAdjusted = body.height() - bodyHeightAdjustment; // 3
        var $scrollTopAnchor = $('.x-scroll-top');

        function sizingUpdate() {
            var bodyOffsetTop = $window.scrollTop();
            if (bodyOffsetTop > (bodyHeightAdjusted * 0.75)) {
                $scrollTopAnchor.addClass('in');
            } else {
                $scrollTopAnchor.removeClass('in');
            }
        }

        $window.on('scroll', sizingUpdate).resize(sizingUpdate);
        sizingUpdate();

        $scrollTopAnchor.on('click', function() {
            $('html, body').animate({
                scrollTop: 0
            }, 850, 'xEaseInOutExpo');
            return false;
        });

    });
</script>


</div> <!-- END .x-root -->


<div class="tco-dc-message">
    <h1>
        <span>This is <a href="">Education</a>, a Site Template from <a href="">Themeco</a> available exclusively in <a href="">Design&nbsp;Cloud</a></span>
    </h1>
    <button>
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16">
            <g>
                <path d="M14.7,1.3c-0.4-0.4-1-0.4-1.4,0L8,6.6L2.7,1.3c-0.4-0.4-1-0.4-1.4,0s-0.4,1,0,1.4L6.6,8l-5.3,5.3 c-0.4,0.4-0.4,1,0,1.4C1.5,14.9,1.7,15,2,15s0.5-0.1,0.7-0.3L8,9.4l5.3,5.3c0.2,0.2,0.5,0.3,0.7,0.3s0.5-0.1,0.7-0.3 c0.4-0.4,0.4-1,0-1.4L9.4,8l5.3-5.3C15.1,2.3,15.1,1.7,14.7,1.3z"></path>
            </g>
        </svg>
    </button>
</div>

<style type="text/css">
    .tco-dc-message {
        display: flex !important;
        flex-flow: row nowrap !important;
        justify-content: center !important;
        align-items: center !important;
        position: fixed !important;
        z-index: 999999999 !important;
        left: 0 !important;
        right: 0 !important;
        bottom: 0 !important;
        padding: 20px !important;
        background-color: #000000 !important;
    }

    .tco-dc-message h1 {
        margin: 0 auto !important;
        border: 2px solid #2f2f2f !important;
        border-radius: 3px !important;
        padding: 10px calc(16px - 0.085em) 10px 16px !important;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol" !important;
        font-size: 13px !important;
        font-weight: 400 !important;
        letter-spacing: 0.075em !important;
        line-height: 1.65 !important;
        text-align: center !important;
        text-transform: uppercase !important;
        color: #888888 !important;
    }

    .tco-dc-message h1 a,
    .tco-dc-message h1 strong {
        font-weight: 700 !important;
        color: #ffffff !important;
    }

    .tco-dc-message h1 a {
        text-decoration: none !important;
    }

    .tco-dc-message h1 a:hover,
    .tco-dc-message h1 a:focus {
        outline: 0 !important;
        text-decoration: underline !important;
    }

    .tco-dc-message button {
        flex: 0 0 auto !important;
        width: 3em !important;
        height: 3em !important;
        margin: 0 0 0 20px !important;
        border: 2px solid #2f2f2f !important;
        border-radius: 100em !important;
        padding: 0 !important;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol" !important;
        font-size: 14px !important;
        font-weight: 400 !important;
        letter-spacing: 0 !important;
        line-height: calc(3em - (2px * 2)) !important;
        color: #ffffff !important;
        background-color: transparent !important;
        transition: border-color 0.2s ease !important;
    }

    .tco-dc-message button svg {
        display: block !important;
        width: 1em !important;
        height: 1em !important;
        margin: auto !important;
        font-size: 1em !important;
        fill: currentColor !important;
        stroke: none !important;
    }

    .tco-dc-message button:hover,
    .tco-dc-message button:focus {
        outline: 0 !important;
        border-color: #888888 !important;
    }
</style>

<script type="text/javascript">
    (function($) {

        var messageShown = true;
        var $html = $('html');
        var $dcMessage = $('.tco-dc-message');

        setPaddingOffset();

        $(window).on('resize', setPaddingOffset);

        $dcMessage.find('button').on('click', function() {
            messageShown = false;
            $html.attr('style', null);
            $dcMessage.remove();
        });

        function setPaddingOffset() {
            if (messageShown) {
                $html.css({
                    'padding-bottom': getMessageHeight()
                });
            }
        }

        function getMessageHeight() {
            return $dcMessage.outerHeight();
        }

    })(jQuery);
</script>

<script type="text/javascript">
    function revslider_showDoubleJqueryError(sliderID) {
        var errorMessage = "Revolution Slider Error: You have some jquery.js library include that comes after the revolution files js include.";
        errorMessage += "<br> This includes make eliminates the revolution slider libraries, and make it not work.";
        errorMessage += "<br><br> To fix it you can:<br>&nbsp;&nbsp;&nbsp; 1. In the Slider Settings -> Troubleshooting set option:  <strong><b>Put JS Includes To Body</b></strong> option to true.";
        errorMessage += "<br>&nbsp;&nbsp;&nbsp; 2. Find the double jquery.js include and remove it.";
        errorMessage = "<span style='font-size:16px;color:#BC0C06;'>" + errorMessage + "</span>";
        jQuery(sliderID).show().html(errorMessage);
    }
</script>
<script type="text/javascript" src="{{ asset('frontassets/js/cs.fe32a70.js') }}" id="cornerstone-site-body-js"></script>
<script type="text/javascript" src="{{ asset('frontassets/js/x.js') }}" id="x-site-js"></script>
<script type="text/javascript" src="{{ asset('frontassets/js/comment-reply.min.js') }}" id="comment-reply-js"></script>
<script type="text/javascript" src="{{ asset('frontassets/js/wp-embed.min.js') }}" id="wp-embed-js"></script>
<script type="text/javascript" id="mediaelement-core-js-before">
    var mejsL10n = {
        "language": "en",
        "strings": {
            "mejs.download-file": "Download File",
            "mejs.install-flash": "You are using a browser that does not have Flash player enabled or installed. Please turn on your Flash player plugin or download the latest version from https:\/\/get.adobe.com\/flashplayer\/",
            "mejs.fullscreen": "Fullscreen",
            "mejs.play": "Play",
            "mejs.pause": "Pause",
            "mejs.time-slider": "Time Slider",
            "mejs.time-help-text": "Use Left\/Right Arrow keys to advance one second, Up\/Down arrows to advance ten seconds.",
            "mejs.live-broadcast": "Live Broadcast",
            "mejs.volume-help-text": "Use Up\/Down Arrow keys to increase or decrease volume.",
            "mejs.unmute": "Unmute",
            "mejs.mute": "Mute",
            "mejs.volume-slider": "Volume Slider",
            "mejs.video-player": "Video Player",
            "mejs.audio-player": "Audio Player",
            "mejs.captions-subtitles": "Captions\/Subtitles",
            "mejs.captions-chapters": "Chapters",
            "mejs.none": "None",
            "mejs.afrikaans": "Afrikaans",
            "mejs.albanian": "Albanian",
            "mejs.arabic": "Arabic",
            "mejs.belarusian": "Belarusian",
            "mejs.bulgarian": "Bulgarian",
            "mejs.catalan": "Catalan",
            "mejs.chinese": "Chinese",
            "mejs.chinese-simplified": "Chinese (Simplified)",
            "mejs.chinese-traditional": "Chinese (Traditional)",
            "mejs.croatian": "Croatian",
            "mejs.czech": "Czech",
            "mejs.danish": "Danish",
            "mejs.dutch": "Dutch",
            "mejs.english": "English",
            "mejs.estonian": "Estonian",
            "mejs.filipino": "Filipino",
            "mejs.finnish": "Finnish",
            "mejs.french": "French",
            "mejs.galician": "Galician",
            "mejs.german": "German",
            "mejs.greek": "Greek",
            "mejs.haitian-creole": "Haitian Creole",
            "mejs.hebrew": "Hebrew",
            "mejs.hindi": "Hindi",
            "mejs.hungarian": "Hungarian",
            "mejs.icelandic": "Icelandic",
            "mejs.indonesian": "Indonesian",
            "mejs.irish": "Irish",
            "mejs.italian": "Italian",
            "mejs.japanese": "Japanese",
            "mejs.korean": "Korean",
            "mejs.latvian": "Latvian",
            "mejs.lithuanian": "Lithuanian",
            "mejs.macedonian": "Macedonian",
            "mejs.malay": "Malay",
            "mejs.maltese": "Maltese",
            "mejs.norwegian": "Norwegian",
            "mejs.persian": "Persian",
            "mejs.polish": "Polish",
            "mejs.portuguese": "Portuguese",
            "mejs.romanian": "Romanian",
            "mejs.russian": "Russian",
            "mejs.serbian": "Serbian",
            "mejs.slovak": "Slovak",
            "mejs.slovenian": "Slovenian",
            "mejs.spanish": "Spanish",
            "mejs.swahili": "Swahili",
            "mejs.swedish": "Swedish",
            "mejs.tagalog": "Tagalog",
            "mejs.thai": "Thai",
            "mejs.turkish": "Turkish",
            "mejs.ukrainian": "Ukrainian",
            "mejs.vietnamese": "Vietnamese",
            "mejs.welsh": "Welsh",
            "mejs.yiddish": "Yiddish"
        }
    };
</script>
<script type="text/javascript" src="{{ asset('frontassets/js/mediaelement-and-player.min.js') }}" id="mediaelement-core-js"></script>
<script type="text/javascript" src="{{ asset('frontassets/js/mediaelement-migrate.min.js') }}" id="mediaelement-migrate-js"></script>
<script type="text/javascript" id="mediaelement-js-extra">
    /* <![CDATA[ */
    var _wpmejsSettings = {
        "pluginPath": "\/education\/wp-includes\/js\/mediaelement\/",
        "classPrefix": "mejs-",
        "stretching": "responsive"
    };
    /* ]]> */
</script>
