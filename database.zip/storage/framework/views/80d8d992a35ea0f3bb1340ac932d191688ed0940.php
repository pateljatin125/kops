<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <?php $__currentLoopData = $reviewrequest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reviewrequestval): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-8">
            <div class="card">
                <?php $log = DB::table('users')->where('id', $reviewrequestval->request_from)->first(); // or whatever, just get one log ?>
                <div class="card-header">Please Write Review For <?php echo $log->company_name;?></div>

                <div class="card-body">

                        <div class="alert alert-success" role="alert">
                            <form method="POST" id="submitreview" name="submitreview">
                                <?php echo csrf_field(); ?>
                                <?php echo e(method_field('POST')); ?>

                                <input type="hidden" value="<?php echo e($requestId); ?>" name="requestId" id="requestId">
                                <input type="hidden" value="<?php echo e($log->google_location); ?>" name="redirectUrl" id="redirectUrl">

                                <div class="form-group row">
                                    <label for="review" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Write Your Review')); ?></label>

                                    <div class="col-md-6">
                                        <textarea id="review"  class="form-control <?php if ($errors->has('review')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('review'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="review" value="<?php echo e(old('review')); ?>" required autocomplete="review" autofocus></textarea>

                                        <?php if ($errors->has('review')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('review'); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($review); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="rating" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Phone')); ?></label>

                                    <div class="col-md-6">
                                        <select id="rating" class="form-control" name="rating" required autocomplete="rating">
                                            <option value="1">1</option>
                                            <option value="2">2</option>
                                            <option value="3">3</option>
                                            <option value="4">4</option>
                                            <option value="5">5</option>
                                        </select>
                                    </div>
                                </div>



                                <div class="form-group row mb-0">
                                    <div class="col-md-8 offset-md-4">
                                        <button type="submit" id="submituserreview" class="btn btn-primary">
                                            <?php echo e(__('SUBMIT YOUR REVIEW')); ?>

                                        </button>
                                    </div>
                                    <div id="response"></div>
                                </div>

                            </form>
                        </div>

                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampdup\htdocs\pdc\resources\views/postreview.blade.php ENDPATH**/ ?>