<?php

namespace App\Http\Controllers;
use DB;
use Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;
use Mail;
use Twilio\Rest\Client;
use Validator;

class ReviewController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */



    public function index()
    {
        //
    }

    public function postreview($id)
    {
        $id = Crypt::decryptString($id);
        $reviewrequest = DB::table('review_requests')
            ->where('id', '=', $id)
            ->get();
        return view('postreview', ['reviewrequest' => $reviewrequest,'requestId' => $id ]);
    }
    public function submitreview(Request $request)
    {
        $data['requestId'] = $request->Input('requestId');
        $data['review'] = $request->Input('review');
        $data['rating'] = $request->Input('rating');
        $redirectUrl = $request->Input('redirectUrl');
        if (!empty($data)) {
            $lastId = DB::table('reviews')->insertGetId($data);
        }
        if($data['rating'] == 5)
        {
            echo json_encode(array("redirect"=>'1','url'=>$redirectUrl));
        }
        else{
            echo json_encode(array("redirect"=>'0'));
        }
        die;
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        $userId = Auth::id();
        $data['request_from'] = $userId;
        $this->userMail = $request->Input('email');
        $data['request_email'] = $request->Input('email');
        $data['request_phone'] = $request->Input('phone');
        if (!empty($data)) {
            $lastId = DB::table('review_requests')->insertGetId($data);
            if($lastId!="")
            {
                $entryId = $lastId;
                $lastId = Crypt::encryptString($lastId);
                $requestToken = Crypt::encryptString( $data['request_from'] );
                $linkurl = "http://127.0.0.1:8000/postreview/".$lastId."?token=".$requestToken;
                //DB::enableQueryLog();
                $randomGenerator = $this->generateRandomString();
                $linkmessage = "http://127.0.0.1:8000/reviewposting/".$randomGenerator;
                $dataUpdate = array( "request_link" => $linkurl,"token"=>$randomGenerator );
                DB::table('review_requests')
                ->where('id', '=', $entryId)
                ->update($dataUpdate);
                //dd(DB::getQueryLog());


                $dataview = array('link'=>$linkurl);
                Mail::send('emails.requestreview', $dataview, function($message) {
                    $message->to( $this->userMail, 'Dalliance Motors')->subject
                        ('Thanks for Visting Us!');
                    $message->from('gaurav@shardainfosys.com','Dalliance Motors');
                });

                if($data['request_phone'] != "") {
                    $this->sendSmsexpert( $data['request_phone'] ,$linkmessage );
                }
                echo "Review request sent!";

            }
            else{
                echo "Something wrong happened!";

            }
            die;
        }
    }

    public function generateRandomString($length = 10) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }

    public function sendSmsexpert($phone,$link)
    {
         // Base URLS for three methods
        $base_url_SendSMS = 'https://www.experttexting.com/ExptRestApi/sms/json/Message/Send';
        $base_url_QueryBalance = 'https://www.experttexting.com/ExptRestApi/sms/json/Account/Balance?';

        // Public Variables that are used as parameters in API calls
        $username = 'shardainfosys';
        $password = 'Admin@123';
        $apikey = 'fk4yo4u60t9qsf0';
        $from = 'DEFAULT';	// USE DEFAULT IN MOST CASES, CONTACT SUPPORT FOR FURTHER DETAILS>
        $to = $phone;		// LET THIS REMAIN BLANK
        $msgtext = 'Thanks for visitng us! Please review us for our service, Click on the link below for posting '.$link;

        $fieldcnt    = 6;
        $fieldstring = "username=$username&password=$password&api_key=$apikey&FROM=$from&to=$to&text=$msgtext";

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $base_url_SendSMS);
        curl_setopt($ch, CURLOPT_POST, $fieldcnt);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fieldstring);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $res = curl_exec($ch);
        $err = curl_error($ch);
        curl_close($ch);
        return true;

    }
    public function sendSms( $phone,$link )
    {
        $link = "https://www.google.com/";
        $msg = "Thanks for visitng us! Please review us for our service, Click on the link below for posting:  ".
       // Your Account SID and Auth Token from twilio.com/console
       $sid    = env( 'TWILIO_SID' );
       $token  = env( 'TWILIO_TOKEN' );
       $client = new Client( $sid, $token );

           $numbers_in_arrays = explode( ',' , $phone );

           $message = $msg;
           $count = 0;

           foreach( $numbers_in_arrays as $number )
           {
               $count++;

               $client->messages->create(
                   $number,
                   [
                       'from' => env( 'TWILIO_FROM' ),
                       'body' => $message,
                   ]
               );
           }
           return true;

   }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
