-- MySQL dump 10.19  Distrib 10.3.31-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: codeufrx_kops
-- ------------------------------------------------------
-- Server version	10.3.31-MariaDB-log-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admins`
--

DROP TABLE IF EXISTS `admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admins` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `employee_code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_super` tinyint(1) NOT NULL DEFAULT 0,
  `customer_group` bigint(20) DEFAULT NULL,
  `department` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admins`
--

LOCK TABLES `admins` WRITE;
/*!40000 ALTER TABLE `admins` DISABLE KEYS */;
INSERT INTO `admins` (`id`, `name`, `employee_code`, `user_id`, `email`, `password`, `is_super`, `customer_group`, `department`, `mobile`, `remember_token`, `created_at`, `updated_at`) VALUES (6,'Test','T001','Ttest','t@gmail.com','$2y$10$QS/dBA7uERSzQ4pULp9w9uixPF4EUOz0vwXSlCZ4fyuqdWqgfubEu',1,1,'a:2:{i:0;s:1:\"6\";i:1;s:1:\"7\";}','',NULL,NULL,NULL),(11,'Testing','Yyuyuhd#123','788398','uisuisii@gmail.com','$2y$10$9ProG3uxAysC5AoEr9zmee7S6P3tDswNBy2lh7HMLRFyC6.YonWxG',1,1,'a:1:{i:0;s:1:\"7\";}','',NULL,NULL,NULL),(26,'sukh','s001','sss','infosukhpinder@gmail.com','$2y$10$lyJnczorc7pWp44qZiGW/OJEg5tbO51TA7PjHSRtdLTzk3k0hqYW2',0,NULL,'a:2:{i:0;s:1:\"7\";i:1;s:2:\"10\";}','',NULL,NULL,NULL);
/*!40000 ALTER TABLE `admins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admins_group`
--

DROP TABLE IF EXISTS `admins_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admins_group` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `code` varchar(191) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admins_group`
--

LOCK TABLES `admins_group` WRITE;
/*!40000 ALTER TABLE `admins_group` DISABLE KEYS */;
INSERT INTO `admins_group` (`id`, `name`, `code`) VALUES (1,'Material','sdsddsdsd'),(2,'Tester','AG2'),(3,'ACCOUNTING','AG3'),(4,'SALES DEPARTMENT','AG4');
/*!40000 ALTER TABLE `admins_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `casting`
--

DROP TABLE IF EXISTS `casting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `casting` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `item` bigint(20) DEFAULT NULL,
  `qty` double DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `created_on` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_on` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `casting`
--

LOCK TABLES `casting` WRITE;
/*!40000 ALTER TABLE `casting` DISABLE KEYS */;
INSERT INTO `casting` (`id`, `item`, `qty`, `remarks`, `created_on`, `updated_on`) VALUES (1,23,1223,'Casting sone','2021-09-05 10:37:43','2021-09-05 19:54:48'),(3,22,123,'JKjskjdk','2021-09-05 20:12:54','2021-09-05 20:12:54'),(4,22,123,'JKjskjdk','2021-09-05 20:13:11','2021-09-05 20:13:11'),(5,22,123,'JKjskjdk','2021-09-05 20:13:39','2021-09-05 20:13:39'),(6,15,0,'Substracting 0.1 from .335','2021-09-05 20:14:49','2021-09-05 20:14:49'),(7,22,200,'CASTING IN','2021-09-20 10:19:51','2021-09-20 10:19:51');
/*!40000 ALTER TABLE `casting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `departments`
--

DROP TABLE IF EXISTS `departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `departments` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) DEFAULT NULL,
  `code` varchar(191) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `departments`
--

LOCK TABLES `departments` WRITE;
/*!40000 ALTER TABLE `departments` DISABLE KEYS */;
INSERT INTO `departments` (`id`, `name`, `code`) VALUES (7,'Machining','002'),(9,'Grinder','003'),(10,'Polish','004'),(11,'Nickel','005'),(12,'Assembling','006'),(13,'Store','007'),(14,'Dispatching','008'),(16,'QC','009'),(17,'Store 2','010'),(18,'Casting','001'),(20,'Store','DEP20');
/*!40000 ALTER TABLE `departments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_group_relation`
--

DROP TABLE IF EXISTS `item_group_relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_group_relation` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `group_id` bigint(20) NOT NULL,
  `items` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_group_relation`
--

LOCK TABLES `item_group_relation` WRITE;
/*!40000 ALTER TABLE `item_group_relation` DISABLE KEYS */;
INSERT INTO `item_group_relation` (`id`, `group_id`, `items`) VALUES (1,9,'a:7:{i:0;s:2:\"15\";i:1;s:2:\"16\";i:2;s:2:\"17\";i:3;s:2:\"18\";i:4;s:2:\"19\";i:5;s:2:\"22\";i:6;s:2:\"26\";}'),(2,7,'a:5:{i:0;s:2:\"15\";i:1;s:2:\"16\";i:2;s:2:\"17\";i:3;s:2:\"18\";i:4;s:2:\"23\";}');
/*!40000 ALTER TABLE `item_group_relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_groups`
--

DROP TABLE IF EXISTS `item_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_groups` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(191) DEFAULT NULL,
  `group_code` varchar(191) NOT NULL,
  `status` enum('1','0') DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_groups`
--

LOCK TABLES `item_groups` WRITE;
/*!40000 ALTER TABLE `item_groups` DISABLE KEYS */;
INSERT INTO `item_groups` (`id`, `group_name`, `group_code`, `status`) VALUES (7,'Outsourcing','OS002','1'),(9,'Casting','C001','1'),(13,'Testing','G10',NULL),(14,'CP FITTING','G14',NULL);
/*!40000 ALTER TABLE `item_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `items`
--

DROP TABLE IF EXISTS `items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `items` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `code` varchar(191) NOT NULL,
  `name` varchar(191) DEFAULT NULL,
  `item_group` text DEFAULT NULL,
  `unit` varchar(191) DEFAULT NULL,
  `size` varchar(191) DEFAULT NULL,
  `weight` varchar(191) DEFAULT NULL,
  `weight1` varchar(191) DEFAULT NULL,
  `weight2` varchar(191) DEFAULT NULL,
  `nickname` varchar(191) DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_on` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` enum('1','0') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `items`
--

LOCK TABLES `items` WRITE;
/*!40000 ALTER TABLE `items` DISABLE KEYS */;
INSERT INTO `items` (`id`, `code`, `name`, `item_group`, `unit`, `size`, `weight`, `weight1`, `weight2`, `nickname`, `created_date`, `updated_on`, `status`) VALUES (15,'LN001','LONG NOSE SOLO','a:1:{i:0;s:1:\"9\";}','PCS','15MM','0.23500000000000001','.280','.245','645','2021-09-03 05:39:10','2021-09-05 20:14:49','1'),(16,'LN002','LONG NOSE CROSS','a:1:{i:0;s:1:\"9\";}','PCS','15MM','0.285','0.235','0.220','645','2021-09-03 05:50:14','2021-09-03 05:50:14','1'),(17,'LN003','LONG NOSE KENT','a:1:{i:0;s:1:\"9\";}','PCS','15MM','0.475','0.405','0.345','800','2021-09-03 05:51:56','2021-09-03 05:51:56','1'),(18,'HD101','HANDLE KRAX','a:1:{i:0;s:1:\"7\";}','PCS','3\"','0','0','.070','145','2021-09-03 05:53:39','2021-09-03 05:53:39','1'),(19,'HD102','HANDLE SQUARE','a:1:{i:0;s:1:\"7\";}','PCS','3\"','0','0','.080','195','2021-09-03 05:54:39','2021-09-03 05:54:39','1'),(20,'SN006','SHORT NOSE SOLO','a:1:{i:0;s:1:\"9\";}','PCS','15MM','0.285','0.265','0.235','580','2021-09-03 05:56:33','2021-09-03 05:56:33','1'),(21,'SN165','SWAN NECK PRIME','a:1:{i:0;s:1:\"9\";}','PCS','15MM','0.490','0.475','0.410','1420','2021-09-03 05:58:19','2021-09-03 05:58:19','1'),(22,'SM320','SINK MIXER KOTAX','a:1:{i:0;s:1:\"9\";}','PCS','15MM','-322.23','0.615','0.625','3315','2021-09-03 06:01:43','2021-09-20 10:19:51','1'),(23,'BF602','BRASS FUN','a:1:{i:0;s:1:\"7\";}','PCS','15MM','0','0','.200','250','2021-09-03 06:03:29','2021-09-03 06:03:29','1'),(24,'PC120','PILLAR COCK KOTAX','a:1:{i:0;s:1:\"7\";}','PCS','15MM','0.550','0.460','0.410','1170','2021-09-03 06:05:19','2021-09-03 06:05:19','1'),(25,'SB1104','SHORT NOSE CROSS','a:1:{i:0;s:1:\"9\";}','PCS','15MM','0.300','0.280','0.250','600','2021-09-06 05:51:59','2021-09-06 05:51:59','1'),(26,'LN1456','LONG NOSE KRETA','a:1:{i:0;s:1:\"9\";}','PCS','15MM','.400','0.380','0.360','750','2021-09-06 08:19:28','2021-09-06 08:19:28','1');
/*!40000 ALTER TABLE `items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2021_02_26_203058_admins',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `modules`
--

DROP TABLE IF EXISTS `modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `modules` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('1','0') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `modules`
--

LOCK TABLES `modules` WRITE;
/*!40000 ALTER TABLE `modules` DISABLE KEYS */;
/*!40000 ALTER TABLE `modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `practice_test`
--

DROP TABLE IF EXISTS `practice_test`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `practice_test` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_on` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` enum('1','0') COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `practice_test`
--

LOCK TABLES `practice_test` WRITE;
/*!40000 ALTER TABLE `practice_test` DISABLE KEYS */;
INSERT INTO `practice_test` (`id`, `name`, `created_on`, `status`) VALUES (7,'ANGLE VALVE','2021-08-10 10:12:39','1'),(8,'LONG NOSE','2021-08-10 10:12:55','1'),(9,'Item 2','2021-08-10 10:29:39','1');
/*!40000 ALTER TABLE `practice_test` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `practice_test_modules`
--

DROP TABLE IF EXISTS `practice_test_modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `practice_test_modules` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `practice_test` bigint(20) NOT NULL,
  `module` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `module_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `practice_test_modules`
--

LOCK TABLES `practice_test_modules` WRITE;
/*!40000 ALTER TABLE `practice_test_modules` DISABLE KEYS */;
/*!40000 ALTER TABLE `practice_test_modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rawmaterial_inward`
--

DROP TABLE IF EXISTS `rawmaterial_inward`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rawmaterial_inward` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `code` varchar(191) NOT NULL,
  `product_name` varchar(191) DEFAULT NULL,
  `price` varchar(191) DEFAULT NULL,
  `weight` varchar(191) DEFAULT NULL,
  `qty` varchar(191) DEFAULT NULL,
  `weight_dimension` enum('pcs','kg') DEFAULT NULL,
  `vendor` text DEFAULT NULL,
  `product_type` varchar(191) DEFAULT NULL,
  `created_on` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_on` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rawmaterial_inward`
--

LOCK TABLES `rawmaterial_inward` WRITE;
/*!40000 ALTER TABLE `rawmaterial_inward` DISABLE KEYS */;
INSERT INTO `rawmaterial_inward` (`id`, `code`, `product_name`, `price`, `weight`, `qty`, `weight_dimension`, `vendor`, `product_type`, `created_on`, `updated_on`) VALUES (1,'001','ABC','233','7','100','pcs','a:1:{i:0;s:1:\"2\";}','RAW','2021-09-11 03:50:32','2021-09-22 01:44:43'),(2,'KSJKSK','jkJKJKJS','189','12','13','pcs','2','jksjksjk','2021-09-11 04:06:52','2021-09-16 03:42:56'),(3,'BR001','BRASS',NULL,NULL,NULL,'kg','1','RAW','2021-09-20 09:58:23','2021-09-20 09:58:23'),(4,'BR002','BRASS','500','2000',NULL,'kg','1','RAW','2021-09-20 10:01:30','2021-09-20 10:01:30'),(5,'PRO5','BRASS',NULL,NULL,NULL,'pcs','a:2:{i:0;s:1:\"3\";i:1;s:1:\"5\";}','RAW','2021-10-01 04:35:01','2021-10-01 04:35:01'),(6,'PRO6','ZISTA','524','45',NULL,'pcs','a:1:{i:0;s:1:\"2\";}','RAW','2021-10-01 04:39:18','2021-10-01 04:39:18');
/*!40000 ALTER TABLE `rawmaterial_inward` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review_form`
--

DROP TABLE IF EXISTS `review_form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `review_form` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `message` text NOT NULL,
  `formelements` text NOT NULL,
  `designed_by` bigint(20) NOT NULL,
  `averagestars` int(11) NOT NULL,
  `status` enum('1','0') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review_form`
--

LOCK TABLES `review_form` WRITE;
/*!40000 ALTER TABLE `review_form` DISABLE KEYS */;
/*!40000 ALTER TABLE `review_form` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review_requests`
--

DROP TABLE IF EXISTS `review_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `review_requests` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `request_from` bigint(20) NOT NULL,
  `request_phone` text DEFAULT NULL,
  `request_email` text DEFAULT NULL,
  `request_link` text DEFAULT NULL,
  `token` text DEFAULT NULL,
  `request_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_on` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` enum('1','0') NOT NULL,
  `review_status` enum('0','1') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review_requests`
--

LOCK TABLES `review_requests` WRITE;
/*!40000 ALTER TABLE `review_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `review_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reviews`
--

DROP TABLE IF EXISTS `reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reviews` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `requestId` bigint(20) NOT NULL,
  `review` text NOT NULL,
  `rating` text NOT NULL,
  `pattern` text NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_on` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` set('1','0') DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reviews`
--

LOCK TABLES `reviews` WRITE;
/*!40000 ALTER TABLE `reviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `reviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_manage_transfer`
--

DROP TABLE IF EXISTS `stock_manage_transfer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stock_manage_transfer` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `department` varchar(191) DEFAULT NULL,
  `qty` varchar(191) DEFAULT NULL,
  `inward_id` bigint(20) DEFAULT NULL,
  `voucher_slip` text DEFAULT NULL,
  `request_by` varchar(191) DEFAULT NULL,
  `created_on` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_on` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_manage_transfer`
--

LOCK TABLES `stock_manage_transfer` WRITE;
/*!40000 ALTER TABLE `stock_manage_transfer` DISABLE KEYS */;
INSERT INTO `stock_manage_transfer` (`id`, `department`, `qty`, `inward_id`, `voucher_slip`, `request_by`, `created_on`, `updated_on`) VALUES (1,'CASTING','12',0,'/tmp/phpx0tntj','FRD','2021-09-12 19:47:33','2021-09-12 19:47:33'),(2,'CASTING','12',0,'/tmp/php3ZVvan','FRD','2021-09-14 03:29:13','2021-09-14 03:29:13'),(3,'CASTING','12',0,'/tmp/phpkQPwN4','FRD','2021-09-14 03:29:33','2021-09-14 03:29:33'),(4,'CASTING','12',0,'Capture.JPG','FRD','2021-09-14 03:34:30','2021-09-14 03:34:30'),(5,'CASTING','12',1,'Capture.JPG','FRD','2021-09-14 04:13:02','2021-09-14 04:13:02'),(6,'10','1',1,'RAJAN SIR T.pdf','Abc','2021-09-14 19:08:33','2021-09-14 19:08:33'),(7,'10','1',1,'RAJAN SIR T.pdf','Abc','2021-09-14 19:08:35','2021-09-14 19:08:35'),(8,'7','1',1,'RAJAN SIR T.pdf','Fg','2021-09-14 19:10:54','2021-09-14 19:10:54'),(9,'7','1',1,'RAJAN SIR T.pdf','Fg','2021-09-14 19:10:56','2021-09-14 19:10:56'),(10,'10','1',1,'RAJAN SIR T.pdf','Xyz','2021-09-14 19:12:56','2021-09-14 19:12:56'),(11,'10','1',1,'RAJAN SIR T.pdf','Xyz','2021-09-14 19:12:57','2021-09-14 19:12:57'),(12,'10','1',1,'RAJAN SIR T.pdf','Xyz','2021-09-14 19:12:58','2021-09-14 19:12:58'),(13,'10','1',1,'RAJAN SIR T.pdf','Xyz','2021-09-14 19:12:58','2021-09-14 19:12:58'),(14,'9','1',1,'RAJAN SIR T.pdf','Xyz','2021-09-14 19:15:08','2021-09-14 19:15:08'),(15,'9','1',1,'RAJAN SIR T.pdf','Xyz','2021-09-14 19:15:10','2021-09-14 19:15:10'),(16,'11','1',1,'detailFox gown.txt','sdd','2021-09-16 04:08:42','2021-09-16 04:08:42'),(17,'7','1',1,'gaurav.pdf','ee','2021-09-20 18:16:58','2021-09-20 18:16:58'),(18,'7','1',1,'gaurav.pdf','ee','2021-09-20 18:17:01','2021-09-20 18:17:01'),(19,'10','5',1,'kops logo.jpg','hjghj','2021-09-21 06:45:57','2021-09-21 06:45:57'),(20,'10','5',1,'kops logo.jpg','hjghj','2021-09-21 06:45:59','2021-09-21 06:45:59'),(21,'10','5',1,'kops logo.jpg','hjghj','2021-09-21 06:45:59','2021-09-21 06:45:59');
/*!40000 ALTER TABLE `stock_manage_transfer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `test_questions`
--

DROP TABLE IF EXISTS `test_questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `test_questions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `section_id` bigint(20) NOT NULL,
  `test_id` bigint(20) NOT NULL,
  `question` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test_questions`
--

LOCK TABLES `test_questions` WRITE;
/*!40000 ALTER TABLE `test_questions` DISABLE KEYS */;
/*!40000 ALTER TABLE `test_questions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `test_sections`
--

DROP TABLE IF EXISTS `test_sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `test_sections` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `test_id` bigint(20) NOT NULL,
  `name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test_sections`
--

LOCK TABLES `test_sections` WRITE;
/*!40000 ALTER TABLE `test_sections` DISABLE KEYS */;
/*!40000 ALTER TABLE `test_sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `industry` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `google_location` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `review_settings` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vendors`
--

DROP TABLE IF EXISTS `vendors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vendors` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) DEFAULT NULL,
  `address` varchar(191) DEFAULT NULL,
  `vendor_code` varchar(191) DEFAULT NULL,
  `contact` varchar(191) DEFAULT NULL,
  `contact2` varchar(191) DEFAULT NULL,
  `contact3` varchar(191) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vendors`
--

LOCK TABLES `vendors` WRITE;
/*!40000 ALTER TABLE `vendors` DISABLE KEYS */;
INSERT INTO `vendors` (`id`, `name`, `address`, `vendor_code`, `contact`, `contact2`, `contact3`, `created_on`) VALUES (1,'GAURAV','jksjksjk','002','jkjksjsk','jksjksjks','','2021-09-14 13:35:07'),(2,'TESTING NAME UPDATE','Jalandhar','T001','988888','8','','2021-09-14 19:03:19'),(3,'RVM','JHADJHAWGD','001','54894621321','012134','','2021-09-20 09:57:09'),(5,'GOPAL DAS','ASFSAF','VEN4','FSEFWE','SFSRGRY','','2021-10-01 04:34:07');
/*!40000 ALTER TABLE `vendors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'codeufrx_kops'
--

--
-- Dumping routines for database 'codeufrx_kops'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-10-01 17:19:41
