<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-12">
            <div class="card shadow-lg border-0 rounded-lg mt-5">
                <div class="card-body">
                    <div class="box-body">
                        <?php if($message = Session::get('success')): ?>
                        <?php Session::forget('success'); ?>
                        <h5 class="error_success" style="color:red;"><?php echo e($message); ?></h5>
                        <?php endif; ?>
                    </div>

                    <!--for the enteries of this week-->
                    <div class="card mb-4">
                        <div class="card-header">
                            <i class="fas fa-table mr-1"></i>
                            ITEM GROUP RELATIONSHIP  <span style="float:right;"><a href="#" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
                                    BUILD RELATIONSHIP
                                </a></span>
                        </div>
                        
                        
                        
                        
                        
                            <div style="display:none;" id="modalForRelationship">
                                <!-- Button trigger modal -->
                            <!-- Modal -->
                            <div class="modal fade" id="relationshipModal" tabindex="-1" role="dialog" aria-labelledby="relationshipModal" aria-hidden="true">
                              <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                  <div class="modal-header">
                                    <h5 class="modal-title" id="relationshipModal">Relationship details</h5>
                                        
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                      <span aria-hidden="true">&times;</span>
                                    </button>
                                  </div>
                                  <div class="modal-body" id="relationshipBody">
                                            
                                  </div>
                                  <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    
                                  </div>
                                </div>
                              </div>
                            </div>
                            </div>
                            
                            
                            
                        
                        <div class="card-body">
                            <div class="table-responsive">
                                <span id="success"></span>
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>Groups</th>
                                            <th>Select Items</th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                            <th>Groups</th>
                                            <th>Select Items</th>
                                        </tr>
                                    </tfoot>
                                    <tbody>
                                        <?php $__currentLoopData = $itemgroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemgroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php 
                                        $itemsInGroups = DB::table('item_group_relation')->where('group_id', $itemgroup->id)->get();
                                        $itemsinGroup = array();
                                        foreach($itemsInGroups as $itemsInGroup)
                                        {
                                            $itemsinGroup = unserialize($itemsInGroup->items);
                                        }
                                        
                                        
                                       
                                        
                                        ?>
                                        <tr>
                                            <td><a style="margin-top:5px;" class="btn btn-primary relationshipdetails" id="Relationship#<?php echo e($itemgroup->id); ?>"><?php echo e($itemgroup->group_name); ?></a></td>
                                            <td><select class="itemselection" name="items[]" multiple="multiple" style="widht:100%;" id="items#<?php echo e($itemgroup->id); ?>">
                                              <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->id); ?>" <?php if(in_array($item->id,$itemsinGroup)) { echo "selected"; } ?>><?php echo e($item->name); ?></option>
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                    </tbody>
                                </table>
                                <?php echo e($itemgroups->links()); ?>

                            </div>
                        </div>
                    </div>
                    <!--enteries for this week ends-->
                </div>
            </div>
        </div>
    </div>
</div>
<style>
    .select2.select2-container
    {
        width:100%!important;
    }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/codeufrx/gtechnocrafts.com/KOPS/resources/views/admin/item_group_relation.blade.php ENDPATH**/ ?>