<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-12">
            <div class="card shadow-lg border-0 rounded-lg mt-5">
                <div class="card-body">
                    <div class="box-body">
                        <?php if($message = Session::get('success')): ?>
                        <?php Session::forget('success'); ?>
                        <h5 class="error_success" style="color:red;"><?php echo e($message); ?></h5>
                        <?php endif; ?>
                    </div>

                    <!--for the enteries of this week-->
                    <div class="card mb-4">
                        <div class="card-header">
                            <i class="fas fa-table mr-1"></i>
                            Reporting  <span style="float:right;"></span>
                        </div>
                        
                        
                        
                        <!-- Button trigger modal -->
                            <!-- Modal -->

                        <div class="card-body">
                           <div class="table-responsive">
                <table class="table table-bordered" id="dataTables" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Department</th>
                            <th>Quantity</th>
                            <th>Voucher Slip</th>
                            <th>Request By</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>Department</th>
                            <th>Quantity</th>
                            <th>Voucher Slip</th>
                            <th>Request By</th>
                        </tr>
                    </tfoot>
                    <tbody>
                        <?php foreach ($transfersData as $transferData) { ?>
                        <tr id="$transferData#<?php echo e($transferData->id); ?>" class="edittrigger">
                            <td><?=$transferData->department;?></td>
                            <td><?=$transferData->qty;?></td>
                            <td><?php echo url('/')."/uploads/".$transferData->voucher_slip;?></td>
                            <td><?=$transferData->request_by;?></td>
                            
                        </tr>
                        <?php } ?>



                    </tbody>
                </table>
            </div>
                        </div>
                    </div>
                    <!--enteries for this week ends-->
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/codeufrx/gtechnocrafts.com/KOPS/resources/views/admin/transfer_report.blade.php ENDPATH**/ ?>