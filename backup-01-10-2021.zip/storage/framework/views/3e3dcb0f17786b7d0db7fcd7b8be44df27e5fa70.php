<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-12">
            <div class="card shadow-lg border-0 rounded-lg mt-5">
                <div class="card-body">
                    <div class="box-body">
                        <?php if($message = Session::get('success')): ?>
                        <?php Session::forget('success'); ?>
                        <h5 class="error_success" style="color:red;"><?php echo e($message); ?></h5>
                        <?php endif; ?>
                    </div>

                    <!--for the enteries of this week-->
                    <div class="card mb-4">
                        <div class="card-header">
                            <i class="fas fa-table mr-1"></i>
                            ITEM GROUPS  <span style="float:right;"><a href="#" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
                                    ADD NEW
                                </a></span>
                        </div>
                        
                        
                        
                        <!-- Button trigger modal -->
                            <!-- Modal -->
                            <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                              <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                  <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Add New ITEM GROUP</h5>
                                        
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                      <span aria-hidden="true">&times;</span>
                                    </button>
                                  </div>
                                  <div class="modal-body">
                                            <form method="POST" action="#" id="additemgroup">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('PUT'); ?>
                                                    <div class="form-row">
                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <label class="small mb-1" for="groupName"><?php echo e(__('Group Name')); ?></label>
                                                                <input id="groupname" type="text"
                                                                    class="py-4 form-control <?php if ($errors->has('groupname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('groupname'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="groupname"
                                                                    value="<?php echo e(old('groupname')); ?>" required autocomplete="groupname" autofocus>
                        
                                                                <?php if ($errors->has('groupname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('groupname'); ?>
                                                                    <span class="invalid-feedback" role="alert">
                                                                        <strong><?php echo e($message); ?></strong>
                                                                    </span>
                                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        
                        
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    
                                                    <div class="form-row">
                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <label class="small mb-1" for="groupCode"><?php echo e(__('Group Code')); ?></label>
                                                                <input id="groupcode" type="text"
                                                                    class="py-4 form-control <?php if ($errors->has('groupcode')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('groupcode'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="groupcode"
                                                                    value="G<?php echo e($lastId); ?>" required autocomplete="groupcode" autofocus readonly>
                        
                                                                <?php if ($errors->has('groupcode')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('groupcode'); ?>
                                                                    <span class="invalid-feedback" role="alert">
                                                                        <strong><?php echo e($message); ?></strong>
                                                                    </span>
                                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        
                        
                                                            </div>
                                                        </div>
                                                    </div>
                        
                                                    <div class="form-group mt-4 mb-0"> <button type="submit" class="btn btn-primary">
                                                            <?php echo e(__('Add Group')); ?>

                                                        </button></div>
                                            <span id="response"></span>
                                            </form>
                                  </div>
                                  <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    
                                  </div>
                                </div>
                              </div>
                            </div>
                            
                            <div style="display:none;" id="modalForEdit">
                                <!-- Button trigger modal -->
                                <!-- Button trigger modal -->
                            <!-- Modal -->
                            <div class="modal fade" id="groupModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                              <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                  <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Edit ITEM GROUP</h5>
                                        
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                      <span aria-hidden="true">&times;</span>
                                    </button>
                                  </div>
                                  <div class="modal-body">
                                            <form method="POST" action="#" id="edititemgroup">
                                                <input type="hidden" name="itemgroupId" id="itemgroupId">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('PUT'); ?>
                                                    <div class="form-row">
                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <label class="small mb-1" for="groupName"><?php echo e(__('Group Name')); ?></label>
                                                                <input id="editgroupname" type="text"
                                                                    class="py-4 form-control <?php if ($errors->has('groupname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('groupname'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="groupname"
                                                                    value="<?php echo e(old('groupname')); ?>" required autocomplete="groupname" autofocus>
                        
                                                                <?php if ($errors->has('groupname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('groupname'); ?>
                                                                    <span class="invalid-feedback" role="alert">
                                                                        <strong><?php echo e($message); ?></strong>
                                                                    </span>
                                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        
                        
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    
                                                    <div class="form-row">
                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <label class="small mb-1" for="groupCode"><?php echo e(__('Group Code')); ?></label>
                                                                <input id="editgroupcode" type="text"
                                                                    class="py-4 form-control <?php if ($errors->has('groupcode')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('groupcode'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="groupcode"
                                                                    value="<?php echo e(old('groupcode')); ?>" required autocomplete="groupcode" autofocus readonly>
                        
                                                                <?php if ($errors->has('groupcode')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('groupcode'); ?>
                                                                    <span class="invalid-feedback" role="alert">
                                                                        <strong><?php echo e($message); ?></strong>
                                                                    </span>
                                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        
                        
                                                            </div>
                                                        </div>
                                                    </div>
                        
                                                    <div class="form-group mt-4 mb-0"> <button type="submit" class="btn btn-primary">
                                                            <?php echo e(__('Edit Group')); ?>

                                                        </button></div>
                                            <span id="responseedit"></span>
                                            </form>
                                  </div>
                                  <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    
                                  </div>
                                </div>
                              </div>
                            </div>
                            
                            </div>
                            
                            
                            

                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>Code</th>
                                            <th>Name</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                            <th>Code</th>
                                            <th>Name</th>
                                            <th>Actions</th>
                                        </tr>
                                    </tfoot>
                                    <tbody>
                                        <?php $__currentLoopData = $itemgroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemgroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($itemgroup->group_code); ?></td>
                                            <td><?php echo e($itemgroup->group_name); ?></td>
                                
                                        <td><a href="itemgroupdestroy/<?php echo e($itemgroup->id); ?>" class="btn btn-primary" onclick="return confirm('Are you sure?')">Delete</a>
                                    <a style="margin-top:5px;" class="btn btn-primary itemgroupedit" id="Itemgroup#<?php echo e($itemgroup->id); ?>">Edit</a></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                    </tbody>
                                </table>
                                <?php echo e($itemgroups->links()); ?>

                            </div>
                        </div>
                    </div>
                    <!--enteries for this week ends-->
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/codeufrx/gtechnocrafts.com/KOPS/resources/views/admin/itemgroups.blade.php ENDPATH**/ ?>