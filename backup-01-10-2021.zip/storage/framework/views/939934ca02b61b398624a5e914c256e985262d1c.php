<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-12">
            <div class="card shadow-lg border-0 rounded-lg mt-5">
                <div class="card-body">
                    <div class="box-body">
                        <?php if($message = Session::get('success')): ?>
                        <?php Session::forget('success'); ?>
                        <h5 class="error_success" style="color:red;"><?php echo e($message); ?></h5>
                        <?php endif; ?>
                    </div>

                    <!--for the enteries of this week-->
                    <div class="card mb-4">
                        <div class="card-header">
                            <i class="fas fa-table mr-1"></i>
                            ITEMS  <span style="float:right;"><a href="#" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
                                    ADD NEW
                                </a></span>
                        </div>
                        
                        
                        
                        <!-- Button trigger modal -->
                            <!-- Modal -->
                            <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                              <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                  <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Add New ITEM</h5>
                                        
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                      <span aria-hidden="true">&times;</span>
                                    </button>
                                  </div>
                                  <div class="modal-body">
                                            <form method="POST" action="#" id="additem">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="form-row">
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label class="small mb-1" for="Itemcode"><?php echo e(__('Item Code')); ?></label>
                                                                <input value="00<?php echo e($lastItemId); ?>" id="code" readonly type="text"
                                                                    class="py-4 form-control <?php if ($errors->has('code')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('code'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="code"
                                                                    value="<?php echo e(old('code')); ?>" autocomplete="code" autofocus>
                        
                                                                <?php if ($errors->has('code')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('code'); ?>
                                                                    <span class="invalid-feedback" role="alert">
                                                                        <strong><?php echo e($message); ?></strong>
                                                                    </span>
                                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        
                        
                                                            </div>
                                                        </div>
                                                    
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label class="small mb-1" for="itemName"><?php echo e(__('Item Name')); ?></label>
                                                                <input id="name" type="text"
                                                                    class="py-4 form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name"
                                                                    value="<?php echo e(old('name')); ?>" autocomplete="name" autofocus>
                        
                                                                <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                                                                    <span class="invalid-feedback" role="alert">
                                                                        <strong><?php echo e($message); ?></strong>
                                                                    </span>
                                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        
                        
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    <div class="form-row">
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label class="small mb-1" for="itemName"><?php echo e(__('Item Group')); ?></label>
                                        <select name="item_group[]" class="form-control <?php if ($errors->has('item_group')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('item_group'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="item_group" multiple>
                                            <option value="">Select Item Group</option>
                                            <?php $__currentLoopData = $itemgroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemgroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <option value="<?php echo e($itemgroup->id); ?>"> <?php echo e($itemgroup->group_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                        </select>
                        
                                        <?php if ($errors->has('item_group')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('item_group'); ?>
                                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        
                        
                                                            </div>
                                                        </div>
                                                    
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label class="small mb-1" for="itemUnit"><?php echo e(__('Item Unit')); ?></label>
                                        <select id="unit" class="form-control <?php if ($errors->has('unit')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('unit'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="unit" autocomplete="unit" autofocus>
                                            <option value="KG">KG</option>
                                            <option value="PCS">PCS</option>
                                        </select>
                        
                                                                <?php if ($errors->has('unit')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('unit'); ?>
                                                                    <span class="invalid-feedback" role="alert">
                                                                        <strong><?php echo e($message); ?></strong>
                                                                    </span>
                                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        
                        
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    <div class="form-row">
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label class="small mb-1" for="itemSize"><?php echo e(__('Item Size')); ?></label>
                                                                <input id="size" type="text"
                                                                    class="py-4 form-control <?php if ($errors->has('size')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('size'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="size"
                                                                    value="<?php echo e(old('size')); ?>" autocomplete="size" autofocus>
                        
                                                                <?php if ($errors->has('size')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('size'); ?>
                                                                    <span class="invalid-feedback" role="alert">
                                                                        <strong><?php echo e($message); ?></strong>
                                                                    </span>
                                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        
                        
                                                            </div>
                                                        </div>
                                                    
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label class="small mb-1" for="itemweight"><?php echo e(__('CASTING WT1')); ?></label>
                                                                <input id="weight" type="text"
                                                                    class="py-4 form-control <?php if ($errors->has('weight')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('weight'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="weight"
                                                                    value="<?php echo e(old('weight')); ?>" autocomplete="weight" autofocus>
                        
                                                                <?php if ($errors->has('weight')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('weight'); ?>
                                                                    <span class="invalid-feedback" role="alert">
                                                                        <strong><?php echo e($message); ?></strong>
                                                                    </span>
                                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        
                        
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    
                                                    
                                                    <div class="form-row">
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label class="small mb-1" for="itemweight2"><?php echo e(__('MACHINING E WT2')); ?></label>
                                                                <input id="weight1" type="text"
                                                                    class="py-4 form-control <?php if ($errors->has('weight2')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('weight2'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="weight1"
                                                                    value="<?php echo e(old('weight2')); ?>" autocomplete="weight2" autofocus>
                        
                                                                <?php if ($errors->has('weight2')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('weight2'); ?>
                                                                    <span class="invalid-feedback" role="alert">
                                                                        <strong><?php echo e($message); ?></strong>
                                                                    </span>
                                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        
                        
                                                            </div>
                                                        </div>
                                                        
                                                        
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label class="small mb-1" for="itemweight3"><?php echo e(__('FINISHEDWT3')); ?></label>
                                                                <input id="weight2" type="text"
                                                                    class="py-4 form-control <?php if ($errors->has('weight3')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('weight3'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="weight2"
                                                                    value="<?php echo e(old('weight3')); ?>" autocomplete="weight3" autofocus>
                        
                                                                <?php if ($errors->has('weight3')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('weight3'); ?>
                                                                    <span class="invalid-feedback" role="alert">
                                                                        <strong><?php echo e($message); ?></strong>
                                                                    </span>
                                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        
                        
                                                            </div>
                                                        </div>
                                                        
                                                        
                                                    </div>
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    <div class="form-row">
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label class="small mb-1" for="itemNRP"><?php echo e(__('Item NICKNAME')); ?></label>
                                                                <input id="nickname" type="text"
                                                                    class="py-4 form-control <?php if ($errors->has('nickname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nickname'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="nickname"
                                                                    value="<?php echo e(old('NRP')); ?>" autocomplete="nickname" autofocus>
                        
                                                                <?php if ($errors->has('nickname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nickname'); ?>
                                                                    <span class="invalid-feedback" role="alert">
                                                                        <strong><?php echo e($message); ?></strong>
                                                                    </span>
                                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        
                        
                                                            </div>
                                                        </div>
                                                    
                                                    </div>
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    <div class="form-group mt-4 mb-0"> <button type="submit" class="btn btn-primary">
                                                            <?php echo e(__('Add ITEM')); ?>

                                                        </button></div>
                                            <span id="response"></span>
                                            </form>
                                  </div>
                                  <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    
                                  </div>
                                </div>
                              </div>
                            </div>
                            
                            
                            
                            
                            
                            <div style="display:none;" id="modalForEdit">
                                <!-- Button trigger modal -->
                            <!-- Modal -->
                            <div class="modal fade" id="itemModal" tabindex="-1" role="dialog" aria-labelledby="itemModal" aria-hidden="true">
                              <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                  <div class="modal-header">
                                    <h5 class="modal-title" id="itemModal">Edit ITEM</h5>
                                        
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                      <span aria-hidden="true">&times;</span>
                                    </button>
                                  </div>
                                  <div class="modal-body">
                                            <form method="POST" action="#" id="edititem">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="itemId" id="itemId">
                                                    <div class="form-row">
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label class="small mb-1" for="Itemcode"><?php echo e(__('Item Code')); ?></label>
                                                                <input id="editcode" type="text"
                                                                    class="py-4 form-control <?php if ($errors->has('code')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('code'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="code"
                                                                    value="<?php echo e(old('code')); ?>" autocomplete="code" autofocus readonly>
                        
                                                                <?php if ($errors->has('code')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('code'); ?>
                                                                    <span class="invalid-feedback" role="alert">
                                                                        <strong><?php echo e($message); ?></strong>
                                                                    </span>
                                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        
                        
                                                            </div>
                                                        </div>
                                                    
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label class="small mb-1" for="itemName"><?php echo e(__('Item Name')); ?></label>
                                                                <input id="editname" type="text"
                                                                    class="py-4 form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name"
                                                                    value="<?php echo e(old('name')); ?>" autocomplete="name" autofocus>
                        
                                                                <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                                                                    <span class="invalid-feedback" role="alert">
                                                                        <strong><?php echo e($message); ?></strong>
                                                                    </span>
                                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        
                        
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    <div class="form-row">
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label class="small mb-1" for="itemName"><?php echo e(__('Item Group')); ?></label>
                                        <select name="item_group[]" class="form-control <?php if ($errors->has('item_group')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('item_group'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="edititem_group" multiple>
                                            <option value="">Select Item Group</option>
                                            <?php $__currentLoopData = $itemgroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemgroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <option value="<?php echo e($itemgroup->id); ?>"> <?php echo e($itemgroup->group_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                        </select>
                        
                                        <?php if ($errors->has('item_group')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('item_group'); ?>
                                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        
                        
                                                            </div>
                                                        </div>
                                                    
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label class="small mb-1" for="itemUnit"><?php echo e(__('Item Unit')); ?></label>
                                                                <select id="editunit" class="form-control <?php if ($errors->has('unit')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('unit'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="unit" autocomplete="unit" autofocus>
                                            <option value="KG">KG</option>
                                            <option value="PCS">PCS</option>
                                        </select>
                        
                                                                <?php if ($errors->has('unit')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('unit'); ?>
                                                                    <span class="invalid-feedback" role="alert">
                                                                        <strong><?php echo e($message); ?></strong>
                                                                    </span>
                                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        
                        
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    <div class="form-row">
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label class="small mb-1" for="itemSize"><?php echo e(__('Item Size')); ?></label>
                                                                <input id="editsize" type="text"
                                                                    class="py-4 form-control <?php if ($errors->has('size')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('size'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="size"
                                                                    value="<?php echo e(old('size')); ?>" autocomplete="size" autofocus>
                        
                                                                <?php if ($errors->has('size')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('size'); ?>
                                                                    <span class="invalid-feedback" role="alert">
                                                                        <strong><?php echo e($message); ?></strong>
                                                                    </span>
                                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        
                        
                                                            </div>
                                                        </div>
                                                    
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label class="small mb-1" for="itemweight"><?php echo e(__('CASTING WT1')); ?></label>
                                                                <input id="editweight" type="text"
                                                                    class="py-4 form-control <?php if ($errors->has('weight')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('weight'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="weight"
                                                                    value="<?php echo e(old('weight')); ?>" autocomplete="weight" autofocus>
                        
                                                                <?php if ($errors->has('weight')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('weight'); ?>
                                                                    <span class="invalid-feedback" role="alert">
                                                                        <strong><?php echo e($message); ?></strong>
                                                                    </span>
                                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        
                        
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    
                                                    
                                                    <div class="form-row">
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label class="small mb-1" for="itemweight2"><?php echo e(__('MACHINING E WT2')); ?></label>
                                                                <input id="editweight1" type="text"
                                                                    class="py-4 form-control <?php if ($errors->has('weigh2t')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('weigh2t'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="weight2"
                                                                    value="<?php echo e(old('weight2')); ?>" autocomplete="weight2" autofocus>
                        
                                                                <?php if ($errors->has('weight2')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('weight2'); ?>
                                                                    <span class="invalid-feedback" role="alert">
                                                                        <strong><?php echo e($message); ?></strong>
                                                                    </span>
                                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        
                        
                                                            </div>
                                                        </div>
                                                        
                                                        
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label class="small mb-1" for="itemweight3"><?php echo e(__('FINISHEDWT3')); ?></label>
                                                                <input id="editweight2" type="text"
                                                                    class="py-4 form-control <?php if ($errors->has('weight3')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('weight3'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="weight3"
                                                                    value="<?php echo e(old('weight3')); ?>" autocomplete="weight3" autofocus>
                        
                                                                <?php if ($errors->has('weight3')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('weight3'); ?>
                                                                    <span class="invalid-feedback" role="alert">
                                                                        <strong><?php echo e($message); ?></strong>
                                                                    </span>
                                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        
                        
                                                            </div>
                                                        </div>
                                                        
                                                        
                                                    </div>
                                                    
                                                    
                                                    <div class="form-row">
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label class="small mb-1" for="itemNRP"><?php echo e(__('Item NRP')); ?></label>
                                                                <input id="editNRP" type="text"
                                                                    class="py-4 form-control <?php if ($errors->has('NRP')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('NRP'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="NRP"
                                                                    value="<?php echo e(old('NRP')); ?>" autocomplete="NRP" autofocus>
                        
                                                                <?php if ($errors->has('NRP')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('NRP'); ?>
                                                                    <span class="invalid-feedback" role="alert">
                                                                        <strong><?php echo e($message); ?></strong>
                                                                    </span>
                                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        
                        
                                                            </div>
                                                        </div>
                                                    
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label class="small mb-1" for="itemMRP"><?php echo e(__('Item NICKNAME')); ?></label>
                                                                <input id="editMRP" type="text"
                                                                    class="py-4 form-control <?php if ($errors->has('editnickname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('editnickname'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="editnickname"
                                                                    value="<?php echo e(old('editnickname')); ?>" autocomplete="editnickname" autofocus>
                        
                                                                <?php if ($errors->has('editnickname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('editnickname'); ?>
                                                                    <span class="invalid-feedback" role="alert">
                                                                        <strong><?php echo e($message); ?></strong>
                                                                    </span>
                                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        
                        
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    
                                                    
                                                    
                                                    
                                                    
                                                
                                                    <div class="form-group mt-4 mb-0"> <button type="submit" class="btn btn-primary">
                                                            <?php echo e(__('UPDATE ITEM')); ?>

                                                        </button></div>
                                            <span id="responseedit"></span>
                                            </form>
                                  </div>
                                  <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    
                                  </div>
                                </div>
                              </div>
                            </div>
                            </div>
                            
                            
                            

                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTables" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>Code</th>
                                            <th>Name</th>
                                            <!--<th>Item Group</th>-->
                                            <th>Unit</th>
                                            <th>Size</th>
                                            <th>Weight</th>
                                            <th>Nickname</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                            <th>Code</th>
                                            <th>Name</th>
                                            <!--<th>Item Group</th>-->
                                            <th>Unit</th>
                                            <th>Size</th>
                                            <th>Weight</th>
                                            <th>Nickname</th>
                                            <th>Actions</th>
                                        </tr>
                                    </tfoot>
                                    <tbody>
                                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr id="itemrow#<?php echo e($item->id); ?>" class="edittrigger">
                                            <td><?php echo e($item->code); ?></td>
                                            <td><?php echo e($item->name); ?></td>
                                            <td><?php echo e($item->unit); ?></td>
                                            <td><?php echo e($item->size); ?></td>
                                            <td><?php echo e($item->weight); ?></td>
                                            <td><?php echo e($item->nickname); ?></td>
                                            <td><a href="itemdestroy/<?php echo e($item->id); ?>" class="btn btn-primary" onclick="return confirm('Are you sure?')">Delete</a>
                                        <a style="margin-top:5px;" class="btn btn-primary itemedit" id="Item#<?php echo e($item->id); ?>">Edit</a></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                    </tbody>
                                </table>
                                <?php echo e($items->links()); ?>

                            </div>
                        </div>
                    </div>
                    <!--enteries for this week ends-->
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/codeufrx/gtechnocrafts.com/KOPS/resources/views/admin/items.blade.php ENDPATH**/ ?>