<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-12">
            <div class="card shadow-lg border-0 rounded-lg mt-5">
                <div class="card-body">
                    <div class="box-body">
                        <?php if($message = Session::get('success')): ?>
                        <?php Session::forget('success'); ?>
                        <h5 class="error_success" style="color:red;"><?php echo e($message); ?></h5>
                        <?php endif; ?>
                    </div>

                    <!--for the enteries of this week-->
                    <div class="card mb-4">
                        <div class="card-header">
                            <i class="fas fa-table mr-1"></i>
                            Vendors  <span style="float:right;"><a href="#" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
                                    ADD NEW VENDOR
                                </a></span>
                        </div>
                        
                        
                        
                        <!-- Button trigger modal -->
                            <!-- Modal -->
                            <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                              <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                  <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Add New Vendor</h5>
                                        
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                      <span aria-hidden="true">&times;</span>
                                    </button>
                                  </div>
                                  <div class="modal-body">
                                            <form method="POST" action="#" id="addvendor">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('PUT'); ?>
                                                    <div class="form-row">
                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <label class="small mb-1" for="vendor"><?php echo e(__('Vendor Name')); ?></label>
                                                                <input id="vendor" type="text"
                                                                    class="py-4 form-control <?php if ($errors->has('vendor')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('vendor'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="vendor"
                                                                    value="<?php echo e(old('vendor')); ?>" required autocomplete="vendor" autofocus>
                        
                                                                <?php if ($errors->has('vendor')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('vendor'); ?>
                                                                    <span class="invalid-feedback" role="alert">
                                                                        <strong><?php echo e($message); ?></strong>
                                                                    </span>
                                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        
                        
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    
                                                    <div class="form-row">
                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <label class="small mb-1" for="Code"><?php echo e(__('Vendor Code')); ?></label>
                                                                <input id="vendor_code" type="text"
                                                                    class="py-4 form-control <?php if ($errors->has('vendor_code')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('vendor_code'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="vendor_code"
                                                                    value="VEN<?php echo e($lastid); ?>"  readonly required autocomplete="vendor_code" autofocus>
                        
                                                                <?php if ($errors->has('vendor_code')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('vendor_code'); ?>
                                                                    <span class="invalid-feedback" role="alert">
                                                                        <strong><?php echo e($message); ?></strong>
                                                                    </span>
                                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        
                        
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    
                                                    
                                                    <div class="form-row">
                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <label class="small mb-1" for="address"><?php echo e(__('Address')); ?></label>
                                                                <input id="address" type="text"
                                                                    class="py-4 form-control <?php if ($errors->has('address')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('address'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="address"
                                                                    value="<?php echo e(old('address')); ?>" required autocomplete="address" autofocus>
                        
                                                                <?php if ($errors->has('address')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('address'); ?>
                                                                    <span class="invalid-feedback" role="alert">
                                                                        <strong><?php echo e($message); ?></strong>
                                                                    </span>
                                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        
                        
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    
                                                    <div class="form-row">
                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <label class="small mb-1" for="Code"><?php echo e(__('Contact 1')); ?></label>
                                                                <input id="contact" type="text"
                                                                    class="py-4 form-control <?php if ($errors->has('contact')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('contact'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="contact"
                                                                    value="<?php echo e(old('contact')); ?>" required autocomplete="contact" autofocus>
                        
                                                                <?php if ($errors->has('contact')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('contact'); ?>
                                                                    <span class="invalid-feedback" role="alert">
                                                                        <strong><?php echo e($message); ?></strong>
                                                                    </span>
                                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        
                        
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    
                                                    <div class="form-row">
                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <label class="small mb-1" for="Code"><?php echo e(__('Contact 2')); ?></label>
                                                                <input id="contact2" type="text"
                                                                    class="py-4 form-control <?php if ($errors->has('contact2')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('contact2'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="contact2"
                                                                    value="<?php echo e(old('contact2')); ?>" required autocomplete="contact2" autofocus>
                        
                                                                <?php if ($errors->has('contact2')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('contact2'); ?>
                                                                    <span class="invalid-feedback" role="alert">
                                                                        <strong><?php echo e($message); ?></strong>
                                                                    </span>
                                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        
                        
                                                            </div>
                                                        </div>
                                                    </div>
                        
                        
                                        
                                        <div class="form-row">
                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <label class="small mb-1" for="Code"><?php echo e(__('Contact 3')); ?></label>
                                                                <input id="contact3" type="text"
                                                                    class="py-4 form-control <?php if ($errors->has('contact3')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('contact3'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="contact3"
                                                                    value="<?php echo e(old('contact3')); ?>" required autocomplete="contact3" autofocus>
                        
                                                                <?php if ($errors->has('contact3')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('contact3'); ?>
                                                                    <span class="invalid-feedback" role="alert">
                                                                        <strong><?php echo e($message); ?></strong>
                                                                    </span>
                                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        
                        
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    
                                                    
                                                    
                                                    
                        
                                                    <div class="form-group mt-4 mb-0"> <button type="submit" class="btn btn-primary">
                                                            <?php echo e(__('Add Vendor')); ?>

                                                        </button></div>
                                            <span id="response"></span>
                                            </form>
                                  </div>
                                  <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    
                                  </div>
                                </div>
                              </div>
                            </div>
                            
                            
                            
                            
                            
                            
                            <div id="">
                                  <!-- Button trigger modal -->
                            <!-- Modal -->
                            <div class="modal fade" id="vendorModal" tabindex="-1" role="dialog" aria-labelledby="vendorModal" aria-hidden="true">
                              <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                  <div class="modal-header">
                                    <h5 class="modal-title" id="vendorModal">Edit Vendor</h5>
                                        
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                      <span aria-hidden="true">&times;</span>
                                    </button>
                                  </div>
                                  <div class="modal-body">
                                            <form method="POST" action="#" id="editvendorr">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="vendorId" id="vendorId">
                                                    
                                                    
                                                    
                                                    <div class="form-row">
                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <label class="small mb-1" for="editvendor"><?php echo e(__('Vendor Name')); ?></label>
                                                                <input id="editvendor" type="text"
                                                                    class="py-4 form-control <?php if ($errors->has('editvendor')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('editvendor'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="editvendor"
                                                                    value="<?php echo e(old('editvendor')); ?>" required autocomplete="editvendor" autofocus>
                        
                                                                <?php if ($errors->has('editvendor')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('editvendor'); ?>
                                                                    <span class="invalid-feedback" role="alert">
                                                                        <strong><?php echo e($message); ?></strong>
                                                                    </span>
                                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        
                        
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    
                                                    <div class="form-row">
                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <label class="small mb-1" for="Code"><?php echo e(__('Vendor Code')); ?></label>
                                                                <input id="editvendor_code" type="text"
                                                                    class="py-4 form-control <?php if ($errors->has('editvendor_code')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('editvendor_code'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="editvendor_code"
                                                                    value="<?php echo e(old('editvendor_code')); ?>" required autocomplete="editvendor_code" autofocus>
                        
                                                                <?php if ($errors->has('editvendor_code')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('editvendor_code'); ?>
                                                                    <span class="invalid-feedback" role="alert">
                                                                        <strong><?php echo e($message); ?></strong>
                                                                    </span>
                                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        
                        
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    
                                                    
                                                    <div class="form-row">
                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <label class="small mb-1" for="editaddress"><?php echo e(__('Address')); ?></label>
                                                                <input id="editaddress" type="text"
                                                                    class="py-4 form-control <?php if ($errors->has('editaddress')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('editaddress'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="editaddress"
                                                                    value="<?php echo e(old('editaddress')); ?>" required autocomplete="editaddress" autofocus>
                        
                                                                <?php if ($errors->has('editaddress')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('editaddress'); ?>
                                                                    <span class="invalid-feedback" role="alert">
                                                                        <strong><?php echo e($message); ?></strong>
                                                                    </span>
                                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        
                        
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    
                                                    <div class="form-row">
                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <label class="small mb-1" for="Code"><?php echo e(__('Contact 1')); ?></label>
                                                                <input id="editcontact" type="text"
                                                                    class="py-4 form-control <?php if ($errors->has('editcontact')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('editcontact'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="editcontact"
                                                                    value="<?php echo e(old('editcontact')); ?>" required autocomplete="editcontact" autofocus>
                        
                                                                <?php if ($errors->has('editcontact')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('editcontact'); ?>
                                                                    <span class="invalid-feedback" role="alert">
                                                                        <strong><?php echo e($message); ?></strong>
                                                                    </span>
                                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        
                        
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    
                                                    <div class="form-row">
                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <label class="small mb-1" for="Code"><?php echo e(__('Contact 2')); ?></label>
                                                                <input id="editcontact2" type="text"
                                                                    class="py-4 form-control <?php if ($errors->has('editcontact2')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('editcontact2'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="editcontact2"
                                                                    value="<?php echo e(old('editcontact2')); ?>" required autocomplete="editcontact2" autofocus>
                        
                                                                <?php if ($errors->has('editcontact2')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('editcontact2'); ?>
                                                                    <span class="invalid-feedback" role="alert">
                                                                        <strong><?php echo e($message); ?></strong>
                                                                    </span>
                                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        
                        
                                                            </div>
                                                        </div>
                                                    </div>
                        
                        
                                        
                                        <div class="form-row">
                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <label class="small mb-1" for="Code"><?php echo e(__('Contact 3')); ?></label>
                                                                <input id="editcontact3" type="text"
                                                                    class="py-4 form-control <?php if ($errors->has('editcontact3')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('editcontact3'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="editcontact3"
                                                                    value="<?php echo e(old('editcontact3')); ?>" required autocomplete="editcontact3" autofocus>
                        
                                                                <?php if ($errors->has('editcontact3')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('editcontact3'); ?>
                                                                    <span class="invalid-feedback" role="alert">
                                                                        <strong><?php echo e($message); ?></strong>
                                                                    </span>
                                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        
                        
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                        
                                                    <div class="form-group mt-4 mb-0"> <button type="submit" class="btn btn-primary">
                                                            <?php echo e(__('Edit Vendor')); ?>

                                                        </button></div>
                                            <span id="responseedit"></span>
                                            </form>
                                  </div>
                                  <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    
                                  </div>
                                </div>
                              </div>
                            </div>
                            
                            </div> 
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            

                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Address</th>
                                            <th>Vendor Code</th>
                                            <th>Contact 1</th>
                                            <th>Contact 2</th>
                                            <th>Contact 3</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                             <th>Name</th>
                                            <th>Address</th>
                                            <th>Vendor Code</th>
                                            <th>Contact 1</th>
                                            <th>Contact 2</th>
                                            <th>Contact 3</th>
                                            <th>Actions</th>
                                        </tr>
                                    </tfoot>
                                    <tbody>
                                        <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($vendor->name); ?></td>
                                            <td><?php echo e($vendor->address); ?></td>
                                            <td><?php echo e($vendor->vendor_code); ?></td>
                                            <td><?php echo e($vendor->contact); ?></td>
                                            <td><?php echo e($vendor->contact2); ?></td>
                                            <td><?php echo e($vendor->contact3); ?></td>
                                            
                                            <td><a href="vendordestroy/<?php echo e($vendor->id); ?>" class="btn btn-primary" onclick="return confirm('Are you sure?')">Delete</a>
                                    <a style="margin-top:5px;" class="btn btn-primary vendoredit" id="vendor#<?php echo e($vendor->id); ?>">Edit</a></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                    </tbody>
                                </table>
                                <?php echo e($vendors->links()); ?>

                            </div>
                        </div>
                    </div>
                    <!--enteries for this week ends-->
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/codeufrx/gtechnocrafts.com/KOPS/resources/views/admin/vendors.blade.php ENDPATH**/ ?>