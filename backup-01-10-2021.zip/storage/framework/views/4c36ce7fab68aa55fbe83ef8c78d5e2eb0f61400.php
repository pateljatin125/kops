<?php $__env->startSection('content'); ?>
  <!-- Breadcomb area Start-->
	<div class="breadcomb-area">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="breadcomb-list">
						<div class="row">
							<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
								<div class="breadcomb-wp">
									<div class="breadcomb-icon">
										<i class="notika-icon notika-support"></i>
									</div>
									<div class="breadcomb-ctn">
										<h2>Sharda Infosys</h2>
										<p>Welcome to Infosys <span class="bread-ntd">Review Panel</span></p>
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-sm-6 col-xs-3">
								<div class="breadcomb-report">
									<button data-toggle="tooltip" data-placement="left" title="Download Report" class="btn"><i class="notika-icon notika-sent"></i></button>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- Breadcomb area End-->
    <!-- Typography area start-->
    <div class="typography-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="typography-list typography-mgn">
                        <h2>About Sharda Infosys</h2>
                        <div class="typography-bd">
                            <h3>We are an IT company</h3>
                            <p>We deals in website development and site promotion</p>
                            <p class="tab-mg-b-0">Review panel is built with the concern to get valuable feedback from the customer</p>
                        </div>
                    </div>
                    <div class="typography-heading typography-mgn mg-t-30">
                        <h2 class="mn-hd-s">Review panel</h2>
                        <div class="typography-hd-cr-1">
                            <h1>How it works?<h1>
                            <p>When a customer visit your store . You will need to grab customer phone number and email. You need to feed this information inside our system to fire a message and email with the review link. SO the user can put the reviews.</p>
                        </div>
                        
                       
                        
                      
                    </div>
                </div>
            </div>
            
                       
                    </div>
                </div>
            </div>
            
            
            
        </div>
    </div>
    <!-- Typography area End-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/f5ypk656rd98/public_html/smsreview/resources/views/welcome.blade.php ENDPATH**/ ?>