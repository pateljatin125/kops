<h1>Hi,</h1>
<p>Thanks for visiting us!</p>
<p>If you could spend sometime for give us reviews</p>
<a href="{{ $link }}">Click Here</a>
Thanks
Dalliance Motors




