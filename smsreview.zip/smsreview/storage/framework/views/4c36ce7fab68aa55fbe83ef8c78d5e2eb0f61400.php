<?php $__env->startSection('content'); ?>
   <div class="col-md-12">

   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/f5ypk656rd98/public_html/smsreview/resources/views/welcome.blade.php ENDPATH**/ ?>