<h1>Hi,</h1>
<p>Thanks for visiting us!</p>
<p>If you could spend sometime for give us reviews</p>
<a href="<?php echo e($link); ?>">Click Here</a>
Thanks
Dalliance Motors




<?php /**PATH /home/f5ypk656rd98/public_html/smsreview/resources/views/emails/requestreview.blade.php ENDPATH**/ ?>