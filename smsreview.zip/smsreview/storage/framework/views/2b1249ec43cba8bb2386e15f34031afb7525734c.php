<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <?php $__currentLoopData = $reviewrequest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reviewrequestval): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-8">
            <div class="card">
                <?php $log = DB::table('users')->where('id', $reviewrequestval->request_from)->first(); // or whatever, just get one log 
				$reviewformdata = DB::table('review_form')->where( "designed_by",$reviewrequestval->request_from )->get()->first();
				$formelements = $reviewformdata->formelements;
				?>
                <div class="card-header">Please Write Review For <?php echo $log->company_name;?></div>

                <div class="card-body">

                        <div class="alert alert-success" role="alert">
                            <form method="POST" id="submitreviewvalue1" name="submitreviewvalue1" action="<?php echo e(route('submitreview')); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo e(method_field('POST')); ?>

                                <input type="hidden" value="<?php echo e($reviewrequestval->request_from); ?>" name="request_from" id="request_from">
								<input type="hidden" value="<?php echo e($requestId); ?>" name="requestId" id="requestId">
                                <input type="hidden" value="<?php echo e($log->google_location); ?>" name="redirectUrl" id="redirectUrl">

                                
								<?php if(!empty($formelements)): ?>
								<?php $arrayFormelements = explode(',',$formelements);
								?>

								<?php $__currentLoopData = $arrayFormelements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="form-example-int">
									<div class="form-group">
										<label><?php echo e($value); ?></label>
										<div class="nk-int-st">
										<input type="range" min="1" max="5" value="20" name="rating[<?php echo e($key); ?>]" data-rangeslider>
										</div>
									</div>
								</div>

								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php else: ?>
								<div class="form-group row">
                                    <label for="rating" class="col-md-4 col-form-label text-md-right"><?php echo e(__('How Many Stars')); ?></label>

                                    <div class="col-md-6">
                                        <div class="budget-wrap">
                                            	<div class="budget">
                                            		
                                            		<div class="content">
                                            			<input type="range" min="1" max="5" value="20" data-rangeslider>
                                            		</div>
                                            	</div>
                                            </div>
                                    </div>
                                </div>
								<?php endif; ?>
                                <div class="form-group row">
                                    <label for="review" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Write Your Review')); ?></label>

                                    <div class="col-md-6">
                                        <textarea id="review"  class="form-control <?php if ($errors->has('review')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('review'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="review" value="<?php echo e(old('review')); ?>" required autocomplete="review" autofocus></textarea>

                                        <?php if ($errors->has('review')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('review'); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($review); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>
                            


                                <div class="form-group row mb-0">
                                    <div class="col-md-8 offset-md-4">
                                        <button type="submit" id="" class="btn btn-primary">
                                            <?php echo e(__('SUBMIT YOUR REVIEW')); ?>

                                        </button>
                                    </div>
                                    <div id="response"></div>
                                </div>

                            </form>
                        </div>

                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<style>
    *,:after,:before{box-sizing:border-box}
.pull-left{float:left}
.pull-right{float:right}
.clearfix:after,.clearfix:before{content:'';display:table}
.clearfix:after{clear:both;display:block}

.rangeslider,
.rangeslider__fill {
	display:block;
	border-radius:10px;
}

.rangeslider {
	position:relative;
}
.rangeslider:after{
	top:50%;
	left:0;
	right:0;
	content:'';
	width:100%;
	height:5px;
	margin-top:-2.5px;
	border-radius:5px;
	position:absolute;
	background:#212131;
}

.rangeslider--horizontal{
	width:100%;
	height:28px;
}

.rangeslider--vertical{
	width:5px;
	min-height:150px;
	max-height:100%;
}
.rangeslider--disabled{
	filter:progid:DXImageTransform.Microsoft.Alpha(Opacity=40);
	opacity:0.4;
}

.rangeslider__fill{
	position:absolute;
	background:#ff637b;
}
.rangeslider--horizontal .rangeslider__fill{
	top:0;
	height:100%;
}
.rangeslider--vertical .rangeslider__fill{
	bottom:0;
	width:100%;
}

.rangeslider__handle{
	top:50%;
	width:28px;
	height:28px;
	cursor:pointer;
	margin-top:-14px;
	background:white;
	position:absolute;
	background:#ff637b;
	border-radius:50%;
	display:inline-block;
}
.rangeslider__handle:active{
	background:#ff5a7b;
}

.rangeslider__fill,
.rangeslider__handle{
	z-index:1;
}
.rangeslider--horizontal .rangeslider__fill{
	top:50%;
	height:5px;
	margin-top:-2.5px;
}

/* Budget */
.budget-wrap{
	padding:40px;
	background:#292942;
	box-shadow:0 25px 55px 0 rgba(0,0,0,.21),0 16px 28px 0 rgba(0,0,0,.22);
}
.budget-wrap .header .title{
	color:#fff;
	font-size:18px;
	margin-bottom:30px;
}
.budget-wrap .header .title .pull-right{
	color:#ff5a84;
	font-size:24px;
	font-weight:400;
}
.budget-wrap .footer{
	margin-top:30px;
}
.budget-wrap .footer .btn{
	color:inherit;
	padding:12px 24px;
	border-radius:50px;
	display:inline-block;
	text-decoration:none;
}
.budget-wrap .footer .btn.btn-def{
	color:#525263;
}
.budget-wrap .footer .btn.btn-pri{
	color:#eee;
	background:#ff5a84;
}
</style>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppdup\htdocs\smsreview\resources\views/postreview.blade.php ENDPATH**/ ?>